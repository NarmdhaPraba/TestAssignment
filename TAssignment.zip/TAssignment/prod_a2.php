<?php

class DatabaseConnection
{
    private $conn;

    public function __construct($host, $username, $password, $database)
    {
        $this->conn = mysqli_connect($host, $username, $password, $database);
        if (!$this->conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
    }

    public function getConnection()
    {
        return $this->conn;
    }
}

class Product
{
    private $SKU;
    private $Name;
    private $Price;
    private $Type;
    private $Size;
    private $Weight;
    private $Height;
    private $Width;
    private $Length;

    public function __construct($SKU, $Name, $Price, $Type, $Size, $Weight, $Height, $Width, $Length)
    {
        $this->SKU = $SKU;
        $this->Name = $Name;
        $this->Price = $Price;
        $this->Type =$Type;
        $this->Size = $Size;
        $this->Weight = $Weight;
        $this->Height = $Height;
        $this->Width = $Width;
        $this->Length = $Length;
    }

    public function saveToDatabase($conn)
    {
        $query = "INSERT INTO product (SKU, Name, Price, Size, Type, Weight, Height, Width, Length)
                  VALUES ('$this->SKU', '$this->Name', '$this->Price', '$this->Size', '$this->Size', '$this->Weight', '$this->Height', '$this->Width', '$this->Length')";

        if (mysqli_query($conn, $query)) {
            echo "Registration successful";
            header('Location: addproduct.php');
        } else {
            echo "Registration unsuccessful";
            echo mysqli_error($conn);
            exit;
        }
    }
}

// Usage example
$database = new DatabaseConnection("localhost", "root", "", "product");
$conn = $database->getConnection();

if (isset($_POST['btnSubmit'])) {
    $SKU = $_POST['SKU'];
    $Name = $_POST['Name'];
    $Price = $_POST['Price'];
    $Size = $_POST['Size'];
    $Type = $_POST9['Type'];
    $Weight = $_POST['Weight'];
    $Height = $_POST['Height'];
    $Width = $_POST['Width'];
    $Length = $_POST['Length'];

    $product = new Product($SKU, $Name, $Price, $Size, $Type, $Weight, $Height, $Width, $Length);
    $product->saveToDatabase($conn);
}
?>
